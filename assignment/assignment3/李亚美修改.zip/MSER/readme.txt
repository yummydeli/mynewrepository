test.jpeg为原图
ans.jpg为处理后的图像
boxes_num=22
